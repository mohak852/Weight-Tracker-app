package com.example.weighttrackerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
